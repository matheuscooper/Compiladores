import argparse
from antlr4 import *
from HtmlLexer import HtmlLexer
from HtmlParser import HtmlParser
from Visitor import Visitor

def main():
    parser = argparse.ArgumentParser(description='Processar um arquivo HTML usando ANTLR.')
    parser.add_argument('file', help='O caminho para o arquivo HTML a ser processado.')
    args = parser.parse_args()

    input_stream = FileStream(args.file, encoding='utf-8')

# input_stream = InputStream(input('? ')) Vc deve passar o txt como parâmetro, a saída será o código hmtl pelo terminal
    lexer = HtmlLexer(input_stream)
    token_stream = CommonTokenStream(lexer)
    parser = HtmlParser(token_stream)
    tree = parser.root()
    visitor = Visitor()
    visitor.visit(tree)


if __name__== '__main__':
    main()